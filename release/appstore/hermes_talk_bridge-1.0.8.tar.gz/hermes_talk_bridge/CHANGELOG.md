# Changelog

## 1.0.8

- Default local-memory raw Talk message retrieval to the current room/session so vague follow-ups do not pull chat history from another conversation in the same namespace.
- Add `TALK_MEMORY_RETRIEVAL_SCOPE=workspace` as an explicit opt-in escape hatch for deliberate cross-room diagnostics.
- Add regression coverage for two-room isolation while keeping durable namespace memories available.

## 1.0.7

- Add Nextcloud Talk thread support for bot posts and proactive `/deliver` calls.
- Allow `/deliver` payloads to create a Talk thread with `threadTitle` / `thread_title` or reply into an existing thread with `threadId` / `thread_id`.
- Pass through optional `silent` and `referenceId` / `reference_id` bot-message fields for scheduled/threaded delivery.
- Map Hermes adapter thread IDs to Talk `threadId` instead of incorrectly treating them as `replyTo` message IDs.

## 1.0.6

- Add optional Nextcloud Talk received-reaction acknowledgements via `TALK_RECEIVED_REACTION`.
- Use Talk's signed bot reaction endpoint as a best-effort pre-Hermes acknowledgement without replacing existing `Working.` / background heartbeat messages.
- Keep reaction failures non-blocking so the final Hermes reply still posts normally.

## 1.0.5

- Fix Hermes gateway startup crash when the native `nextcloud_talk` platform plugin is enabled for cron delivery.
- Make the Nextcloud Talk cron adapter satisfy Hermes' platform adapter startup contract while remaining delivery-only for inbound Talk traffic.
- Return a real boolean from plugin config validation so missing delivery environment variables are rejected correctly.

## 1.0.4

- Ship native Hermes `deliver=nextcloud_talk` cron delivery support through the bridge-owned platform plugin and installer.
- Add README setup instructions for installing the native plugin into a Hermes Agent tree.
- Keep `/deliver` successful after a Talk post even if optional local memory sync fails, so a bad memory database cannot make Hermes mark an already-posted cron message as failed.

## 1.0.3

- Add a Talk context-priority guard so vague follow-ups prioritize the newest user request and source/session/git history over stale room state.

## 1.0.2

- Harden optional Talk voice transcription and media/image resolution so missing local helper commands such as `docker`, `sudo`, `ffmpeg`, or whisper.cpp return best-effort fallbacks instead of crashing webhook extraction.
- Add regression coverage for Docker-unavailable voice-message handling and missing optional media helper commands.
- Keep public example skill preloads generic and correct App Store submission notes to the current release tag.

## 1.0.1

- Add built-in Talk slash-command emulation for `/help`, `/status`, `/memory`, `/tools`, `/reset`, `/version`, and `/queue` so Nextcloud Talk users can use Telegram-style text commands through the bridge even though native Talk chat commands were removed in favor of bots.
- Add regression coverage proving slash commands post directly from the bridge without spawning Hermes for simple status/reset commands.

## 1.0.0

- Add Talk-visible Hermes skill-management guidance: when the `skills` toolset is enabled, Hermes is prompted to report created/updated/deleted skill names in the final Nextcloud Talk reply.
- Add Talk image-share vision handling: the bridge resolves uploaded/shared images to a local readable cache and injects a `vision_analyze` instruction so Hermes can inspect pictures directly from Nextcloud Talk without asking users for an extra upload step.
- Promote the bridge to version 1.0.0 after production rollout across the managed Talk bot fleet.

## 0.2.0

- Add Nextcloud AppAPI/External App metadata for App Store submission.
- Add Docker packaging for the bridge runtime with Hermes Agent installed in the container.
- Add AppAPI lifecycle endpoints: `/heartbeat`, `/init`, and `/enabled`.
- Add release scripts for CSR generation, app signing, and App Store tarball creation.
- Keep public App Store submission docs concise by omitting certificate-request/key-handling instructions.

- Add CI and GHCR Docker publish workflows.
- Preserve the Talk context packet header/persona instructions when large local memory context must be truncated.


## 0.1.4 - 2026-06-17

- Add an optional `NEXTCLOUD_AI_CONTEXT` hook that injects bounded Nextcloud document/file search context into Hermes prompts when explicitly enabled.

## 0.1.3 - 2026-06-08

- Add optional local voice-message transcription for Nextcloud Talk audio/file-share webhook payloads using ffmpeg plus whisper.cpp when local Nextcloud data access is available.
- Correct the previous voice-message behavior where audio shares were only described as uploaded files and the assistant had to ask for typed text even when the audio file was locally available.
- Keep transcription best-effort: if local file resolution or transcription is unavailable, the bridge still handles the Talk file event without crashing.

## 0.1.2 - 2026-06-07

- Accept rendered Nextcloud Talk file-placeholder events where webhook content uses `{"message":"{file}","parameters":{"file":...}}` instead of `file_shared`, including non-Create `Activity` events for voice recordings.
- Use file-object MIME type/path/name metadata when explicit `metaData` is absent, so audio shares are still identifiable by `audio/*` MIME values or file names.

## 0.1.1 - 2026-06-07

- Accept Nextcloud Talk `file_shared` JSON events even when the object type is not `Note` or the activity type is a non-Create file-share event, covering uploaded files and voice-message shares that some Talk deployments emit outside normal text-message events.
- Preserve a guard against unrelated non-Note Create events so the bridge does not treat arbitrary object payloads as chat messages.
- Keep actor-name extraction safely quoted/defaulted for voice/file-share handling to avoid crashes when actor names are absent.
- Fix editable-install package discovery so `systemd/` is excluded from the Python package set.
- Add regression tests for normal text, bot-loop suppression, non-Note voice/file-share extraction, missing actor names, and unrelated non-Note rejection.
